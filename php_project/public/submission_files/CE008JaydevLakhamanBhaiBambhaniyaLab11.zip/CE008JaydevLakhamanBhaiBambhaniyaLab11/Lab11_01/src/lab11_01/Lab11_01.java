/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_01;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import javax.persistence.Id;
import javax.persistence.TypedQuery;
import mypack.employee;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 *
 * @author HP
 */
public class Lab11_01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SessionFactory sessionFactory;
        ServiceRegistry serviceRegistry;
        Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
        serviceRegistry = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties()).build();
// builds a session factory from the service registry
        sessionFactory= configuration.buildSessionFactory(serviceRegistry);
        Session openSession = sessionFactory.openSession();

        Transaction t = openSession.beginTransaction();

        System.out.println("begin transaction" + t);
             
        Serializable save = openSession.save(new employee(1,"kevin", "computer","developer",750000));
        openSession.saveOrUpdate(new employee(2,"Raj", "chemical","plant manager",550000));
        openSession.persist(new employee(3,"jay", "mba","abc",650000));
        openSession.getTransaction().commit();
        System.out.println("saved");
        employee e = (employee) openSession.get(employee.class, 1);
        System.out.println("Employee Name: "+e.getName());
        System.out.println("Employee Department: "+e.getDepartment());
        System.out.println("Employee Designation: "+e.getDesignation());
        System.out.println("Employee salary: "+e.getSallary());
//        TypedQuery query;
//        query = (TypedQuery) openSession.createQuery("from employee");
//        List<employee> l = query.getResultList();
//        Iterator<employee> itr = l.iterator();
//        while(itr.hasNext())
//        {
//            employee e = itr.next();
//            System.out.println("Employee Id: "+ e.getId());
//            System.out.println("Employee Name: "+ e.getName());
//            System.out.println("Employee Department: "+ e.getDepartment());
//            System.out.println("Employee Designation: "+ e.getDesignation());
//            System.out.println("Employee Id: "+ e.getSallary());
//        }
        StandardServiceRegistryBuilder.destroy(serviceRegistry);
    
}

    }