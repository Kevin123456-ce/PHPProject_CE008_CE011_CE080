package mypack;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="employee" ,catalog="hibernate")
public class employee implements java.io.Serializable {
    private int id;
    private String name;
    private String department;
    private String designation;
    private double sallary;
    public employee() {}
    public employee(int id, String name, String department,String designation,double sallary)
    {
        this.id = id;
        this.name = name;
        this.department = department;
        this.designation = designation;
        this.sallary = sallary;
    }
    @Id
    @Column(name="id", unique=true,nullable=false)
    public int getId() {
        return this.id;
    }
    public void setId(int id) 
    {
        this.id = id;
    }
    @Column(name="name", nullable=false,length=30)
    public String getName() 
    {
        return this.name;
    }
    public void setName(String name) 
    {
        this.name = name;
    }
    @Column(name="department", nullable=true,length=30)
    public String getDepartment() 
    {
        return this.department;
    }
    public void setDepartment(String department) 
    {
        this.department = department;
    }
    @Column(name="designation", nullable=true,length=30)
    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
    @Column(name="salary", nullable=true)
    public double getSallary() {
        return sallary;
    }

    public void setSallary(double sallary) {
        this.sallary = sallary;
    }
    @Override
    public String toString() 
    {
        return "Employee" + "id=" + id + ", name=" +name + ", department=" + department + '}';
    }
}