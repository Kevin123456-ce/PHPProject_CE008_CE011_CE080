/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
/**
 *
 * @author Admin
 */
@Entity
@Table(name="Customer" ,catalog="hibernate")
public class Customer {
    private int id;
    private String name;
    private String address;
    private String contact_no;
    List<OrderData>order;
    public Customer(){
    }

    public Customer(int id, String name, String address, String contact_no, List<OrderData> order) {
        this.id=id;
        this.name=name;
        this.address=address;
        this.contact_no=contact_no;
        this.order = order;
    }
    @Id
    @Column(name="id", unique=true, nullable=false)
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    @Column(name="name", nullable=false)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    @Column(name="address", unique=true, nullable=false)
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    @Column(name="contact_no", unique=true, nullable=false)
    public String getContact_no() {
        return contact_no;
    }

    public void setContact_no(String contact_no) {
        this.contact_no = contact_no;
    }
    @OneToMany(targetEntity=mypack.OrderData.class, cascade=CascadeType.ALL)
    @JoinColumn(name="c_id")
    public List<OrderData> getOrder() {
        return order;
    }

    public void setOrder(List<OrderData> order) {
        this.order = order;
    }
    @Override
    public String toString(){
        return "Customer{ id="+id+" , name="+name+" , address="+address+" , contactNo="+contact_no+"}";
    }
}
