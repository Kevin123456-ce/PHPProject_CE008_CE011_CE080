/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_02;

import java.util.ArrayList;
import java.util.List;
import mypack.Customer;
import mypack.OrderData;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

/**
 *
 * @author Admin
 */
public class Lab11_02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SessionFactory sessionFactory;
        ServiceRegistry serviceRegistry;
        Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
        serviceRegistry = new StandardServiceRegistryBuilder()
                .applySettings(configuration.getProperties()).build();
// builds a session factory from the service registry
        sessionFactory= configuration.buildSessionFactory(serviceRegistry);
        Session openSession = sessionFactory.openSession();

        Transaction t = openSession.beginTransaction();

//        System.out.println("begin transaction" + t);
//        OrderData o1 = new OrderData(1,"chocolate","it is new Chocolate");
//        OrderData o2 = new OrderData(2,"soap","it is dettol");
//        OrderData o3 = new OrderData(3,"handWash","it will remove virus");
//        OrderData o4 = new OrderData(4,"selfie stick","it is selfie  stick");
//        List<OrderData> l1 = new ArrayList<>();
//        l1.add(o1);
//        l1.add(o2);
//        List<OrderData> l2 = new ArrayList<>();
//        l2.add(o3);
//        l2.add(o4);
//        Customer c1 = new Customer(1,"jaydev","rapar","9081978888",l1);
//        Customer c2 = new Customer(2,"kevin","ndd","9884978888",l2);
//        openSession.persist(c1);
//        openSession.persist(c2);
        System.out.println("Customer Data: ");
        Customer c = (Customer) openSession.get(Customer.class, 1);
        System.out.println("Customer Id: " + c.getId());
        System.out.println("Customer Name: " + c.getName());
        System.out.println("Customer Address: " + c.getAddress());
        System.out.println("Customer Contact No: " + c.getContact_no());
        System.out.println("Order data for Customer id=1: ");
        OrderData d1 = (OrderData) openSession.get(OrderData.class, 1);
        OrderData d2 = (OrderData) openSession.get(OrderData.class, 2);
        System.out.println("First Order:");
        System.out.println("Order product Name: "+ d1.getProduct_name());
        System.out.println("Order product Date: "+ d1.getOrder_date());
        System.out.println("Order product Name: "+ d1.getDescription());
        System.out.println("Second Order:");
        System.out.println("Order product Name: "+ d2.getProduct_name());
        System.out.println("Order product Date: "+ d2.getOrder_date());
        System.out.println("Order product Name: "+ d2.getDescription());
        openSession.getTransaction().commit();
        openSession.close();
        StandardServiceRegistryBuilder.destroy(serviceRegistry);
    }
    
}
